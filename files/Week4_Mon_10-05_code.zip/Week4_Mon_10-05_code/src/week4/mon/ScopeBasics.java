package week4.mon;

// POINT: a variable can be used only inside the { } where it was declared,
//        from its declaration down to that block's closing brace.
// ASK:   For any variable: where was it declared, and where does that block end?
public class ScopeBasics {

    public static void main(String[] args) {
        printMessage();     // LMS Part 2.1: local scope
        greet("Alice");     // LMS Part 2.2: parameter scope
        blockScope();       // LMS Part 2.3: block scope (if)
        loopScope();        // LMS Part 2.3 and Part 5: block scope (for)
        nestedScope();      // LMS Part 5: an inner block can see outer variables
        countCall();        // LMS Part 3: lifetime of a local variable
        countCall();
    }

    // LMS Part 2.1: Local Scope
    static void printMessage() {
        String message = "Hello, World!";
        System.out.println(message);              // works: message was declared in this method
    }


    // LMS Part 2.2: Method Scope (Parameters)
    // BUG CHECK 1: uncomment the last line. Why can't greet() see message?
    //              (cannot find symbol: message exists only inside printMessage)
    static void greet(String name) {
        System.out.println("Hello, " + name);     // name exists only inside greet()
        // System.out.println(message);
    }

    // LMS Part 2.3: Block Scope (if)
    // BUG CHECK 2: uncomment the last line. (cannot find symbol: x ended at the closing brace)
    static void blockScope() {
        if (true) {
            int x = 10;
            System.out.println(x);                // works
        }
        // System.out.println(x);
    }

    // LMS Part 2.3 and Part 5: Block Scope (for)
    // BUG CHECK 3: uncomment the last line. Then fix it WITHOUT deleting it.
    //              (declare  int i;  above the loop and start the loop with  for (i = 0; ...) )
    static void loopScope() {
        for (int i = 0; i < 3; i++) {
            System.out.println("Inside loop: " + i);
        }
        // System.out.println("After loop: " + i);
    }

    // LMS Part 5: Nested Scope
    // PREDICT: what prints? The inner block can see x. Can the outer block see y?
    static void nestedScope() {
        int x = 5;
        if (x > 0) {
            int y = 10;
            System.out.println(x + y);            // inner block sees x (outer) and y (its own)
        }
        // System.out.println(y);                 // the outer block cannot see y
    }

    // LMS Part 3: Variable Lifetime
    // PREDICT: main calls this twice. Does the second call print 1 or 2? (1: a new calls each time)
    // BUG CHECK 4 (LMS Part 7): delete "= 0" on the first line.
    //              (variable calls might not have been initialized: locals get no default value)
    static void countCall() {
        int calls = 0;                            // created when the method starts
        calls++;
        System.out.println("calls = " + calls);
    }                                             // gone when the method ends
}
