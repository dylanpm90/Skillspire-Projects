package week4.mon;

// POINT: for every single turn of the outer loop, the inner loop runs from start to finish.
//        Outer loop = rows. Inner loop = columns.
// ASK:   The outer loop runs 3 times and the inner loop runs 4 times.
//        How many times does the inner body run? (12)
public class NestedLoops {

    public static void main(String[] args) {
        multiplicationTable();   // LMS Part 3
        nestedWhile();           // LMS Part 4
        print2DArray();          // LMS Part 5
        rightTriangle();         // LMS Part 6, Example 1
        invertedTriangle();      // LMS Part 6, Example 2
        squarePattern();        // LMS Part 6, Example 3
        seatReservation();       // LMS Part 8, Example 2


        for (int i = 0; i <= 3; i++) { // 0 1 2 3
            System.out.println("Week3 retrival: " + i);



        }

    }

    // LMS Part 3: Multiplication Table
    // PREDICT: how many numbers print? (3 rows x 3 columns = 9)
    // CHANGE:  delete the empty System.out.println(). What happens? (all 9 on one line)
    static void multiplicationTable() {
        System.out.println("--- 1. Multiplication table ---");
        for (int i = 1; i <= 3; i++) {              // outer: one turn per row
            for (int j = 1; j <= 3; j++) {          // inner: runs fully for each row
                System.out.print(i * j + " ");
            }
            System.out.println();                   // the row is finished: start a new line
        }
    }

    // LMS Part 4: Nested While Loops
    // BUG CHECK: move "int j = 1;" up, above the outer while. Run it.
    //            (Only row 1 prints. j is still 4, so the inner loop never runs again.)
    static void nestedWhile() {
        System.out.println("--- 2. Nested while ---");
        int i = 1;
        while (i <= 3) {
            int j = 1;                              // a fresh j for every row
            while (j <= 3) {
                System.out.print("i: " + i + "," + "j: " + j + " ");
                j++;
            }
            System.out.println();
            i++;
        }
    }

    // LMS Part 5: Nested Loops with Arrays (Week 3's 2D arrays, walked with index loops)
    // ASK:       what is matrix.length? what is matrix[i].length? (rows; columns in row i)
    // BUG CHECK: change the inner "<" to "<=". (prints 1 2 3, then ArrayIndexOutOfBoundsException)
    static void print2DArray() {
        System.out.println("--- 3. 2D array ---");
        int[][] matrix = {
            {1, 2, 3},
            {4, 5, 6},
            {7, 8, 9}
        };

        for (int i = 0; i < matrix.length; i++) {
            for (int j = 0; j < matrix[i].length; j++) {
                System.out.print(matrix[i][j] + " ");
            }
            System.out.println();
        }
    }

    // LMS Part 6, Example 1: Right Triangle
    // POINT:   the inner limit uses the outer variable (j <= i), so every row is one longer.
    // PREDICT: how many stars in total? (1 + 2 + 3 + 4 + 5 = 15)
    static void rightTriangle() {
        System.out.println("--- 4. Right triangle ---");
        for (int i = 1; i <= 5; i++) { // i = 3
            for (int j = 1; j <= i; j++) {
                System.out.print("* ");
            }
            System.out.println();
        }
    }

    // LMS Part 6, Example 2: Inverted Triangle
    // PREDICT before running: only the outer loop header changed. What prints?
    static void invertedTriangle() {
        System.out.println("--- 5. Inverted triangle ---");
        for (int i = 5; i >= 1; i--) {
            for (int j = 1; j <= i; j++) {
                System.out.print("* ");
            }
            System.out.println();
        }
    }


    static void squarePattern(){

        System.out.println("--- Square pattern ---");

        for (int i = 1; i <= 3; i++) { // i =1 2
            for (int j = 1; j <= 3; j++) {
                System.out.print("# ");
            }
            System.out.println();
        }

    }

    // LMS Part 8, Example 2: Seat Reservation System
    // PREDICT: how many lines print as written? (9: new boolean[3][3] starts all false)
    // CHANGE:  add  seats[1][1] = true;  above the loops. Which line disappears? (Seat 1,1)
    static void seatReservation() {
        System.out.println("--- 6. Seat reservation ---");
        boolean[][] seats = new boolean[3][3];

        for (int row = 0; row < seats.length; row++) {
            for (int col = 0; col < seats[row].length; col++) {
                if (!seats[row][col]) {
                    System.out.println("Seat " + row + "," + col + " is available");
                }
            }
        }
    }
}
