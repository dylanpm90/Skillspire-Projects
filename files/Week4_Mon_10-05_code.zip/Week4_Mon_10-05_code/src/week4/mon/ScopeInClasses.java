package week4.mon;

// POINT: a field is declared in the class, outside the methods, so all of the object's methods can use it.
//        Instance field = one copy per object. static field = one copy shared by the whole class.
// ASK:   I make two objects. How many copies of this variable exist?
public class ScopeInClasses {

    public static void main(String[] args) {

        // LMS Part 2.4: Instance Scope. Each object gets its own copy of model.
        Car car1 = new Car();
        Car car2 = new Car();
        car1.setModel("Tesla Model 3");
        car2.setModel("Toyota Corolla");
        car1.drive();
        car2.drive();

        // LMS Part 2.5: Class Scope (static). One count, shared by every Counter.
        // PREDICT before running: what prints?
        new Counter();
        new Counter();
        new Counter();
        System.out.println("Total counter count: " + Counter.count);

        // LMS Part 4: Shadowing
        // PREDICT, run, then delete "this." inside setName and run again.
        Student student = new Student();
        student.setName("Alice");
        System.out.println(student.name);
    }
}

class Car {
    String model;                        // instance variable: one per Car object

    public void setModel(String m) {
        model = m;                       // m is a parameter: gone when setModel ends
    }

    void drive() {
        System.out.println(model + " is driving.");   // a second method, the same field
    }
}

class Counter {
    static int count = 0;                // class variable: one copy for the whole class

    public Counter() {                   // constructor: runs each time "new Counter()" runs
        count++;
    }
}

class Student {
    String name = "Default";

    public void setName(String name) {
        this.name = name;                // this.name = the field. name = the parameter.
    }
}
