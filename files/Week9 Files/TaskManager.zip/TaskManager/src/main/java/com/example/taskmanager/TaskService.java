package com.example.taskmanager;

import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class TaskService {
    private final TaskRepository taskRepository;

    public TaskService(TaskRepository taskRepository) {
        this.taskRepository = taskRepository;
    }

    public Task addTask(Task task) {
        return taskRepository.save(task);
    }

    public List<Task> getAllTasks() {
        return taskRepository.findAll();
    }

    public Task getTask(Long id) {
        return taskRepository.findById(id).orElse(null);
    }

    public Task updateTask(Long id, Task changes) {
        Task existing = taskRepository.findById(id).orElse(null);
        if (existing == null) {
            return null;
        }

        existing.setTitle(changes.getTitle());
        existing.setDescription(changes.getDescription());
        existing.setDueDate(changes.getDueDate());
        existing.setCompleted(changes.isCompleted());

        return taskRepository.save(existing);

    }

    public boolean deleteTask(Long id) {
        if (!taskRepository.existsById(id)) {
            return false;
        }

        taskRepository.deleteById(id);
        return true;
    }

    public Task patchTask(Long id, Task changes) {
        Task existing = taskRepository.findById(id).orElse(null);
        if (existing == null) {
            return null;
        }
        if (changes.getTitle() != null) {
            existing.setTitle(changes.getTitle());
        }

        if (changes.getDescription() != null) {
            existing.setDescription(changes.getDescription());
        }

        if (changes.getDueDate() != null) {
            existing.setDueDate(changes.getDueDate());
        }

        // will there be an issue with isCompleted?
        return taskRepository.save(existing);

    }
}

