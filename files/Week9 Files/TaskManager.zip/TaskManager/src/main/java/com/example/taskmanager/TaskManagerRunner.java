package com.example.taskmanager;


import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class TaskManagerRunner implements CommandLineRunner {
    private final TaskRepository taskRepository;
    private final TaskService taskService;

    public TaskManagerRunner(TaskRepository taskRepository, TaskService taskService){
        this.taskRepository = taskRepository;
        this.taskService = taskService;
    }

    @Override
    public void run(String... args){
        // create some tasks
        Task task1 = new Task(
                "get groceries",
                "milk, creamer, ramen",
                "Monday",
                false
        );

        Task task2 = new Task(
                "drop off mail",
                "mom's address is 123 Emerald Cove, Seattle, WA 11111",
                "Tuesday",
                false);

        Task task3 = new Task(
                "pick up bike from shop",
                "bring cash for repairs",
                "Sunday",
                true
        );
        taskService.addTask(task1);
        taskService.addTask(task2);
        taskService.addTask(task3);

        System.out.println(task1);
        System.out.println(task2);
        System.out.println(task3);



    }

}
