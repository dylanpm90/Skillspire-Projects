package com.example.taskmanager;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/tasks")
public class TaskPageController {
    private final TaskService taskService;

    public TaskPageController(TaskService taskService){
        this.taskService = taskService;
    }

    private Task findOrThrow(Long id){
        Task task = taskService.getTask(id);
        if (task == null){
            throw new TaskNotFoundException(id);
        }
        return task;
    }

    @ExceptionHandler(TaskNotFoundException.class)
    @ResponseStatus(HttpStatus.NOT_FOUND)
    public String handleNotFound(){
        return "task-not-found";
    }

    @GetMapping // list page
    public String list(Model model){
        model.addAttribute("tasks", taskService.getAllTasks());
        return "task-list";
    }

    @GetMapping("/{id}") // single task page
    public String showTask(@PathVariable("id") Long id, Model model){
        model.addAttribute("task", findOrThrow(id));
        return "task-details";
    }

    @GetMapping("/new") // add a new task
    public String showForm(Model model){
        model.addAttribute("task", new Task());
        return "task-form";
    }

    @PostMapping
    public String create(@ModelAttribute("task") Task task,
                         RedirectAttributes redirectAttributes){
        taskService.addTask(task);
        redirectAttributes.addFlashAttribute("message",
                "Task added!");
        return "redirect:/tasks";
    }

    @GetMapping("/{id}/edit")
    public String showEditForm(@PathVariable("id") Long id, Model model){
        model.addAttribute("task", findOrThrow(id));
        return "task-edit";
    }

    @PostMapping("/{id}/edit")
    public String update(@PathVariable("id") Long id,
                         @ModelAttribute("task") Task changes,
                         RedirectAttributes redirectAttributes){
        if (taskService.updateTask(id, changes) == null){
            throw new TaskNotFoundException(id);
        }
        redirectAttributes.addFlashAttribute("message",
                "Task updated!");
        return "redirect:/tasks/" + id;
    }

    @PostMapping("/{id}/delete")
    public String delete(@PathVariable("id") Long id,
                         RedirectAttributes redirectAttributes){
        if (!taskService.deleteTask(id)){
            throw new TaskNotFoundException(id);
        }
        redirectAttributes.addFlashAttribute("message",
                "Task " + id + " deleted");
        return "redirect:/tasks";
    }

}
