package com.example.taskmanager;

import jakarta.persistence.*;

import java.sql.DatabaseMetaData;
import java.sql.Date;
import java.time.LocalDateTime;

@Entity
@Table(name = "tasks")
public class Task {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String title;
    private String description;
    private String dueDate;
    private boolean completed;

    protected Task() {
    }

    public Task(
            String title,
            String description,
            String dueDate,
            boolean completed) {
        this.title = title;
        this.description = description;
        this.dueDate = dueDate;
        this.completed = completed;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDueDate() {
        return dueDate;
    }

    public void setDueDate(String dueDate) {
        this.dueDate = dueDate;
    }

    public boolean isCompleted() {
        return completed;
    }

    public void setCompleted(boolean completed) {
        this.completed = completed;
    }

    @Override
    public String toString() {
        String newLine = System.lineSeparator();
        return          "__________________________________" + newLine +
                        "Task ID: " + id + newLine +
                        "Title: " + title + newLine +
                        "Desc: " + description + newLine +
                        "Due Date: " + dueDate + newLine +
                        "Completed?: " + completed + newLine;

    }
}
