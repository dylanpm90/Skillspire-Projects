package week5.fri;

// Point: a child class gets the parent's fields and methods for free, adds its own,
//        and can replace (override) a parent method or extend it with super.method().
// Ask:   Student has no introduce() method. Why does s.introduce() compile?

// ===== Section 1: extends (LMS Class Inheritance P1-P3, P7 hierarchical) =====

class Person {
    String name;
    int age;

    void introduce() {
        System.out.println("Hi, I am " + name + ", age " + age);
    }
}

class Student extends Person {      // a Student IS A Person
    String course;

    void study() {
        System.out.println(name + " is studying " + course);
    }
}

class Teacher extends Person {      // one parent, two children
    String subject;

    void teach() {
        System.out.println(name + " teaches " + subject);
    }
}

// ===== Section 2: overriding (LMS P4) and Section 3: super.method() (LMS P5) =====

class Animal {
    void sound() {
        System.out.println("Some sound");
    }

    void eat() {
        System.out.println("Eating...");
    }
}

class Dog extends Animal {
    @Override
    void sound() {                  // OVERRIDING: same name, same parameters, replaces Animal's
        System.out.println("Bark");
    }

    void sound(int times) {         // OVERLOADING (Wednesday): same name, different parameters
        for (int i = 0; i < times; i++) {
            sound();
        }
    }

    @Override
    void eat() {                    // Section 3
        super.eat();                // run Animal's eat() first...
        // EXTRA: change super.eat(); to eat(); and run
        System.out.println("Dog is eating bones...");   // ...then add Dog's part
    }
}

class Cat extends Animal {
    @Override
    void sound() {                  // * SPOT THE BUG: rename sound to sond, run; then delete @Override and run
        System.out.println("Meow");
    }
}

public class InheritanceBasics {
    public static void main(String[] args) {
        // ----- Section 1 -----
        Student s = new Student();
        s.name = "Alice";               // name and age come from Person
        s.age = 20;
        s.course = "Computer Science";  // course is Student's own
        s.introduce();                  // * PREDICT: does this line compile? What prints?
        s.study();

        Teacher t = new Teacher();
        t.name = "Mr. Lee";
        t.age = 45;
        t.subject = "Java";
        t.introduce();
        t.teach();
        // t.study();                   // SPOT THE BUG: uncomment

        // ----- Section 2 -----
        new Animal().sound();
        new Dog().sound();              // * PREDICT: Some sound or Bark? And the Cat?
        new Cat().sound();

        Dog d = new Dog();
        d.sound(2);                     // PREDICT: which sound() is overriding, which is overloading?

        // ----- Section 3 -----
        d.eat();                        // * PREDICT: how many lines, in what order?
    }
}
