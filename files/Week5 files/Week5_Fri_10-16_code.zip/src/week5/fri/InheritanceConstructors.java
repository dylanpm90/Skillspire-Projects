package week5.fri;

// Point: every constructor starts by running its parent's constructor, so the parent finishes first.
//        super(...) hands values up to the parent, because the child can't set the parent's private fields.
// Ask:   new ElectricCar(...) runs three constructors. Whose line prints first?

// LMS Class Inheritance P5 (super for constructors), P6 (order), P7 (multilevel)

class Vehicle {
    private String brand;

    Vehicle(String brand) {         // Vehicle's ONLY constructor needs a brand
        this.brand = brand;
        System.out.println("1. Vehicle constructor: " + brand);
    }

    String getBrand() {
        return brand;
    }
}

class Car extends Vehicle {
    private int doors;

    Car(String brand, int doors) {
        super(brand);               // * SPOT THE BUG: comment out this line and run
        this.doors = doors;
        System.out.println("2. Car constructor: " + doors + " doors");
    }

    int getDoors() {
        return doors;
    }
}

class ElectricCar extends Car {     // multilevel: Vehicle -> Car -> ElectricCar
    private int rangeKm;

    ElectricCar(String brand, int doors, int rangeKm) {
        super(brand, doors);        // hands two values up to Car
        this.rangeKm = rangeKm;
        System.out.println("3. ElectricCar constructor: " + rangeKm + " km");
    }

    void describe() {
        // brand and doors are private in the parents, so ask for them with the getters
        System.out.println(getBrand() + ", " + getDoors() + " doors, " + rangeKm + " km range");
    }
}

public class InheritanceConstructors {
    public static void main(String[] args) {
        ElectricCar ev = new ElectricCar("Tesla", 4, 500);   // * PREDICT: the order of the three lines
        ev.describe();

        System.out.println("---");
        Car c = new Car("Honda", 4);                         // PREDICT: how many constructor lines now?
    }
}
