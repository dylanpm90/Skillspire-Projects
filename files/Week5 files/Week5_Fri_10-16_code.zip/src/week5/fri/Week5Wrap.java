package week5.fri;

import java.util.ArrayList;

// Point: this one small hierarchy uses all seven Week 5 lessons.
//        A child can't touch the parent's private fields; it uses getters or super.toString().
// Ask:   find each of this week's seven lessons in this file.

// LMS Class Inheritance P8 Example 2 (Product -> Electronics), P9 (breaking encapsulation)

class Product {
    private String name;
    private double price;

    Product(String name, double price) {
        this.name = name;
        setPrice(price);            // Wednesday: the constructor uses the setter's check
    }

    public String getName() {
        return name;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        if (price < 0) {
            System.out.println("Invalid price: " + price);
            return;
        }
        this.price = price;
    }

    @Override
    public String toString() {
        return name + " $" + price;
    }
}

class Electronics extends Product {
    private int warrantyYears;

    Electronics(String name, double price, int warrantyYears) {
        super(name, price);
        this.warrantyYears = warrantyYears;
    }

    Electronics(String name, double price) {
        this(name, price, 1);       // default: 1-year warranty
    }

    @Override
    public String toString() {
        return super.toString() + ", " + warrantyYears + "-year warranty";
        // * SPOT THE BUG: use the line below instead of the line above
        // return name + " $" + price + ", " + warrantyYears + "-year warranty";
    }
}

public class Week5Wrap {
    public static void main(String[] args) {
        ArrayList<Product> cart = new ArrayList<>();
        cart.add(new Product("Notebook", 3.5));
        cart.add(new Electronics("Laptop", 1200.0, 2));   // an Electronics IS A Product, so it fits
        cart.add(new Electronics("Mouse", 25.0));
        // EXTRA: uncomment and predict
        // cart.add(new Electronics("Cable", -5.0));

        double total = 0;
        for (Product p : cart) {
            System.out.println(p);  // PREDICT: whose toString() runs for each line?
            total += p.getPrice();  // getPrice() is inherited by Electronics
        }
        System.out.println("Total: " + total);
    }
}
