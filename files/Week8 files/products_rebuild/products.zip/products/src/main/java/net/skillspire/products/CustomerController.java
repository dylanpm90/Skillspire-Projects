package net.skillspire.products;

import java.nio.file.Path;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("api/customers")
public class CustomerController {
    private final CustomerService customerService;
    private final CustomerRepository customerRepo;


    public CustomerController(CustomerService customerService,
                              CustomerRepository customerRepo) {
        this.customerService = customerService;
        this.customerRepo = customerRepo;
    }

    @GetMapping // get all customers
    public List<Customer> getAllCustomers(){
        return customerService.getAllCustomers();
    }

    @GetMapping("/{id}") // get customer by ID
    public ResponseEntity<Customer> getCustomerById(@PathVariable("id") Long customerId){
        Customer customer = customerService.getCustomer(customerId);

        if(customer == null) {
            return ResponseEntity.notFound().build();
        }

        return ResponseEntity.ok(customer);

    }

    @GetMapping("/{customer_id}/orders/{order_id}")
    public ResponseEntity<Order> getCustomerOrderById(@PathVariable("id") Long customerId,
                                                      @PathVariable("id") Long orderId){
        Order order = customerService.getCustomerOrderById(orderId);
        if (order == null){
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(order);

    }

}
