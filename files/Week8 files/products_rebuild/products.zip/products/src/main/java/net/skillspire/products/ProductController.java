package net.skillspire.products;

import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("api/products")
public class ProductController {
    private final ProductService productService;

    public ProductController(ProductService productService){
        this.productService = productService;
    }

    @GetMapping // get all products
    public List<Product> getAllProducts(){
        return productService.getAllProducts();
    }

    @GetMapping("/{id}") // get a product by its id
    public ResponseEntity<Product> getProductById(@PathVariable("id") Long productId){
        Product product = productService.getProduct(productId);
        if (product == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(product);
    }

    @GetMapping("{id}/category")
    public ResponseEntity<String> getProductCategory(@PathVariable("id") Long productId){
        String category = productService.getProductCategory(productId);

        return ResponseEntity.ok(category);
    }

    @GetMapping("/search")
    public List<Product> search(@RequestParam(value = "category", required = false) String category, @RequestParam(name = "max price", defaultValue = "100") double maxPrice){
        return productService.search(category,maxPrice);
    }

    @PostMapping
    public ResponseEntity<Product> addProduct(@RequestBody Product product){
        Product saved = productService.addProduct(product);
        return ResponseEntity.status(HttpStatus.CREATED).body(saved);
    }

    @PutMapping("{id}")
    public ResponseEntity<Product> updateProduct(@PathVariable("id") Long productId,
                                                 @RequestBody Product product){
        Product updated = productService.updateProduct(productId, product);
        if (updated == null){
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(updated);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteProduct(@PathVariable("id") Long productId){
        if (productService.deleteProduct(productId)){
            return ResponseEntity.ok("Product " + productId + " deleted.");
        }
        return ResponseEntity.notFound().build();
    }

}
