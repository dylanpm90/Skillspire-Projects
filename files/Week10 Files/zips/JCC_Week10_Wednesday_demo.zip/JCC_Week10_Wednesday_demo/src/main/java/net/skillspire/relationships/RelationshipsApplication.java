package net.skillspire.relationships;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RelationshipsApplication {
    public static void main(String[] args) {
        SpringApplication.run(RelationshipsApplication.class, args);
    }
}
